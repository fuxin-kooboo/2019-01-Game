# Philips-Subscription-Frontend

This project is about that product subscription of philips 

---

## Relevant command

``` bash
##################################

# install dependencies
$ npm install # Or yarn install

##################################

# serve with hot reload at localhost:8080
# launch dev server
$ npm run serve

##################################

# build for production and launch server
$ npm run build

##################################

# run lint (eslint)
$ npm run lint

##################################

# run unit
$ npm run test:unit

##################################

# run e2e
$ npm run test:e2e