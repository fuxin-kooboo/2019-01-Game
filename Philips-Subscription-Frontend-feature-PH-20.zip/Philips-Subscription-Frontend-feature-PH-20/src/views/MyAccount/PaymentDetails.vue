<template>
  <div class="MyAccoutPage_PersonalDetails">
    this is MyAccoutPage Payment Details Page
  </div>
</template>

<script>
  export default {
    name: 'payment-details'
  }
</script>
