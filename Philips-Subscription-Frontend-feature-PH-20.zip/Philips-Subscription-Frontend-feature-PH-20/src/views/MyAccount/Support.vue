<template>
  <div class="MyAccoutPage_PersonalDetails">
    this is MyAccoutPage support Page
  </div>
</template>

<script>
  export default {
    name: 'support'
  }
</script>
