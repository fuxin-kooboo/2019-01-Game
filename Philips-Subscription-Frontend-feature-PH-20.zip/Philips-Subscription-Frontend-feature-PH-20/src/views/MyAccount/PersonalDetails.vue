<template>
  <div class="MyAccoutPage_PersonalDetails">
    this is MyAccoutPage PersonalDetails Page
  </div>
</template>

<script>
  export default {
    name: 'personal-details'
  }
</script>
