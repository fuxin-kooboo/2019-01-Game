<template>
  <div class="MyAccoutPage_Billing">
    this is MyAccoutPage Billing Page
  </div>
</template>

<script>
  export default {
    name: 'billing'
  }
</script>
