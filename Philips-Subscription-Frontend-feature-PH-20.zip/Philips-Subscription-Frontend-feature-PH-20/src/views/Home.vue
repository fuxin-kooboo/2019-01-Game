<template>
  <div class="home">
    this is home
  </div>
</template>

<script>
  export default {
    name: 'home'
  }
</script>
