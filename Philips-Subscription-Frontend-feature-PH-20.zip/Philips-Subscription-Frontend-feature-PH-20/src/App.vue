<template>
  <div id="app" :class="{'theme-official': isMyAccountPage }">
    <notifications position="top center" class="app-notification" />
    <app-header class="app-header" />
    <main class="main">
      <router-view />
    </main>
    <app-footer class="app-footer"/>
  </div>
</template>

<script>
  import AppHeader from 'components/AppHeader'
  import AppFooter from 'components/AppFooter'

  export default {
    components: {
      AppHeader,
      AppFooter
    },

    computed: {
      routePath () {
        return this.$route.path
      },

      isMyAccountPage () {
        return /^(\/my-account)/.test(this.routePath)
      }
    },

    created () {
      this.$store.dispatch('checkout/fetchProduct')
    }
  }
</script>

<style lang="scss">
  .main {
    padding-top: .48rem;
  }
</style>
