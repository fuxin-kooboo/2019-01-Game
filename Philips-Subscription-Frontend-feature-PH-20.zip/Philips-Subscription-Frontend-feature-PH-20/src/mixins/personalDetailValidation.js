export default {
  data () {
    return {
      showValidations: false,
      firstName: '',
      lastName: '',
      phoneNumber: '',
      emailAddress: '',
      password: '',
      confirmPassword: ''
    }
  }
}
