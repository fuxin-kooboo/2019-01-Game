export default {
  ApiHost: 'https://philipssubscription-api.azurewebsites.net'
}
